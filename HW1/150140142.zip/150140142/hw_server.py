# A server application that receives messages from multi clients.
#!/usr/bin/python
from socket import *
import threading
import time

global i
i = 0

class ThreadedServer():
    def listenToClient(self, client, addr):
        global i
        while True:
            client.send("Welcome to the quiz program.\n")
            authentication = client.recv(1024)

            client.send("Please enter your name: ")
            message1 = client.recv(1024)

            if len(message1.split()) >= 2:
                name, surname = message1.split()
            else:
                name = message1.split()

            if message1 == "exit":
                print addr, " is closed"
                client.close()
                exit(0)
            else:
                print addr, " says: ", message1

            client.send("Please enter your password: ")
            message2 = client.recv(1024)
            password = message2

            if message2 == "exit":
                print addr, " is closed"
                client.close()
                exit(0)
            else:
                print addr, " says: ", message2

            file = open("students.txt", "r")
            str_file = file.read()

            if str_file.find(name[i]) != -1:
                if len(message1.split()) >= 2:
                    if str_file.find(surname[i]) != -1:
                        if str_file.find(password[i]) != -1:
                            client.send("Authentication is completed.\n")

                            client.send("Please write 'yes' to give attendance.")
                            attendance = client.recv(1024)
                            file2 = open("attendance.txt", "w")
                            if attendance == "yes" or "Yes" or "YES" or "y" or "Y":
                                file2.write(name[i])
                                file2.write(surname[i])
                                file2.write(": yes")
                                file2.close()

                            localtime1 = time.localtime(time.time())[4]
                            print localtime1

                            client.send(" Question:\n")
                            client.send("'.MOV' extension refers usually to what kind of file?")
                            answer = client.recv(1024)
                            client.send("'OS' computer abbreviation usually means ?")
                            answer = client.recv(1024)
                            client.send("Who is largely responsible for breaking the German Enigma codes, created a test that provided a foundation for AI?")
                            answer = client.recv(1024)
                            client.send("What do we call a network whose elements may be separated by some distance?\nIt usually involves two or more small networks and dedicated high-speed telephone lines.")
                            answer = client.recv(1024)
                            client.send("'.TMP' extension refers usually to what kind of file?")
                            answer = client.recv(1024)
                            client.send("What does AM mean?")
                            answer = client.recv(1024)
                            client.send("What was the first ARPANET message?")
                            answer = client.recv(1024)
                            client.send("'FET' is a type of transistor, Its full name is ________ Effect Transistor...?")
                            answer = client.recv(1024)
                            client.send("'CD' computer abbreviation usually means ?")
                            answer = client.recv(1024)
                            client.send("'DB' computer abbreviation usually means ?")
                            answer = client.recv(1024)

                            localtime2 = time.localtime(time.time())[4]
                            timestamp = localtime2 - localtime1
                            if timestamp > 30:
                                print "Your time is up!\n"
                                client.close()
                        else:
                            client.send("Authentication cannot be completed.\n")
                    else:
                        client.send("Authentication cannot be completed.\n")

                else:
                    if str_file.find(password[i]):
                        client.send("Authentication is completed.\n")

                        client.send("Please write 'yes' to give attendance.")
                        attendance = client.recv(1024)
                        file2 = open("attendance.txt", "w")
                        if attendance == "yes" or "Yes" or "YES" or "y" or "Y":
                            file2.write(name[i])
                            file2.write(": yes")
                            file2.close()

                        localtime1 = time.localtime(time.time())[4]
                        print localtime1

                        client.send(" Question:\n")
                        client.send("'.MOV' extension refers usually to what kind of file?")
                        answer = client.recv(1024)
                        client.send("'OS' computer abbreviation usually means ?")
                        answer = client.recv(1024)
                        client.send("Who is largely responsible for breaking the German Enigma codes, created a test that provided a foundation for AI?")
                        answer = client.recv(1024)
                        client.send("What do we call a network whose elements may be separated by some distance?\nIt usually involves two or more small networks and dedicated high-speed telephone lines.")
                        answer = client.recv(1024)
                        client.send("'.TMP' extension refers usually to what kind of file?")
                        answer = client.recv(1024)
                        client.send("What does AM mean?")
                        answer = client.recv(1024)
                        client.send("What was the first ARPANET message?")
                        answer = client.recv(1024)
                        client.send("'FET' is a type of transistor, Its full name is ________ Effect Transistor...?")
                        answer = client.recv(1024)
                        client.send("'CD' computer abbreviation usually means ?")
                        answer = client.recv(1024)
                        client.send("'DB' computer abbreviation usually means ?")
                        answer = client.recv(1024)

                        localtime2 = time.localtime(time.time())[4]
                        timestamp = localtime2 - localtime1
                        if timestamp > 30:
                            print "Your time is up!\n"
                            client.close()
            else:
                client.send("Authentication cannot be completed.\n")

            i = i + 1
            file.close()


    def __init__(self, serverPort, serverName):

        try:
            serverSocket = socket(AF_INET, SOCK_STREAM)

        except:

            print "Socket cannot be created!!!"
            exit(1)

        print "Socket is created..."

        try:
            serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        except:

            print "Socket cannot be used!!!"
            exit(1)

        print "Socket is being used..."

        try:
            serverSocket.bind((serverName, serverPort))
        except:

            print "Binding cannot de done!!!"
            exit(1)

        print "Binding is done..."

        try:
            serverSocket.listen(45)
        except:

            print "Server cannot listen!!!"
            exit(1)

        print "The server is ready to receive"

        while True:
            connectionSocket, addr = serverSocket.accept()

            threading.Thread(target=self.listenToClient, args=(connectionSocket, addr)).start()


if __name__ == "__main__":
    serverName = "160.75.26.161"
    serverPort = 12000
    ThreadedServer(serverPort, serverName)

