Please put the students.txt file with the same folder with hw_server.py.
Students' name and password information will be checked from this file and authentication will be done according to this information.
